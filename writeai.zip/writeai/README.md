# ✦ WriteAI — Grammar & Content Rewriter

An AI-powered writing assistant that checks grammar, fixes spelling, and rewrites content using Claude AI.

![WriteAI Screenshot](https://via.placeholder.com/800x400?text=WriteAI+Screenshot)

## Features

- **Grammar & Spelling Checker** — detects and corrects errors with severity ratings
- **Content Rewriter** — rewrites text in 6 tones (Professional, Casual, Academic, Creative, Concise, Formal)
- **Full Analysis** — readability score, grade level, strengths, and improvement tips
- Powered by [Claude claude-sonnet-4-20250514](https://www.anthropic.com) (Anthropic)

---

## Quick Start

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/writeai.git
cd writeai
```

### 2. Install dependencies

```bash
npm install
```

### 3. Set up your API key

```bash
cp .env.example .env
```

Open `.env` and paste your Anthropic API key:

```
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxxxx
PORT=3000
```

> Get your API key at: https://console.anthropic.com/

### 4. Run the app

```bash
npm start
```

Open your browser at **http://localhost:3000**

---

## Project Structure

```
writeai/
├── public/
│   └── index.html      # Frontend UI
├── server.js           # Express backend (API proxy)
├── package.json
├── .env.example        # API key template (safe to commit)
├── .env                # Your actual key — NEVER commit this
└── .gitignore
```

---

## Deploying to the Web

### Render (free tier)
1. Push this repo to GitHub
2. Go to [render.com](https://render.com) → New Web Service
3. Connect your GitHub repo
4. Set Build Command: `npm install`
5. Set Start Command: `npm start`
6. Add environment variable: `ANTHROPIC_API_KEY = sk-ant-...`

### Railway
1. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
2. Add `ANTHROPIC_API_KEY` in the Variables tab

### Vercel / Netlify
These are best for static sites. For this project (Node.js backend), use **Render** or **Railway** instead.

---

## Security

- Your API key is stored only in `.env` on the server — never sent to the browser
- `.gitignore` ensures `.env` is never committed to GitHub
- The frontend calls `/api/analyze` (your own server), not Anthropic directly

---

## License

MIT
